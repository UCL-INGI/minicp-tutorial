/*
 * mini-cp is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License  v3
 * as published by the Free Software Foundation.
 *
 * mini-cp is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY.
 * See the GNU Lesser General Public License  for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with mini-cp. If not, see http://www.gnu.org/licenses/lgpl-3.0.en.html
 *
 * Copyright (c)  2018. by Laurent Michel, Pierre Schaus, Pascal Van Hentenryck
 */


import minicp.cp.Factory;
import minicp.engine.constraints.Circuit;
import minicp.engine.constraints.Element1D;
import minicp.engine.constraints.Element1DVar;
import minicp.engine.constraints.TableCT;
import minicp.engine.core.IntVar;
import minicp.engine.core.MiniCP;
import minicp.engine.core.Solver;
import minicp.search.DFSearch;
import minicp.search.SearchStatistics;
import minicp.util.io.InputReader;

import java.util.Arrays;
import java.util.stream.IntStream;

import static minicp.cp.BranchingScheme.and;
import static minicp.cp.BranchingScheme.firstFail;
import static minicp.cp.Factory.*;

/**
 * DARP
 * @author Pierre Schaus
 *
 */
public class DARP {

    public static IntVar elementVar(IntVar[] array, IntVar y) {
        Solver cp = y.getSolver();
        int min = IntStream.range(0, array.length).map(i -> array[i].min()).min().getAsInt();
        int max = IntStream.range(0, array.length).map(i -> array[i].max()).max().getAsInt();
        IntVar z = makeIntVar(cp, min,max);
        cp.post(new Element1DVar(array, y, z));
        return z;
    }


    public static void main(String[] args) {

        // coordinates of the positions involved in this problem
        int [][] coords = new int[][] {
                {10,20},
                {30,30},
                {50,40},
                {40,10},
                {50,20},
                {25,30},
                {10,5}
        };

        // compute the symmetrical transition times as Euclidian distances
        int [][] transitions = new int[coords.length][coords.length];
        for (int i = 0; i < coords.length; i++) {
            for (int j = 0; j < coords.length; j++) {
                int x1 = coords[i][0];
                int y1 = coords[i][1];
                int x2 = coords[j][0];
                int y2 = coords[j][1];
                transitions[i][j] = (int) Math.sqrt(Math.pow(x1-x2,2.0)+Math.pow(y1-y2,2.0));
            }
            System.out.println(Arrays.toString(transitions[i]));
        }


        // the requests defined as {fromPos,toPos,deadline}
        int [][] requests = new int[][] {
                {3,5,120},
                {6,2,200},
                {5,1,100},
                {1,6,60},
                {5,2,150},
                {6,3,150},
        };

        // capacity of the vehicle
        int vehicleCapacity = 2;


        int n = requests.length;
        int [] positionIdx = new int[2*n+1];
        positionIdx[0] = 0; // departure at position index 0
        // [1..n+1] = pickups
        // [n+1..2n+1] = delivery
        for (int i = 0; i < requests.length; i++) {
            positionIdx[i+1] = requests[i][0];
            positionIdx[n+i+1] = requests[i][1];
        }


        // TODO 1 create the solver

        // solution https://www.rot13.com
        // Fbyire pc = znxrFbyire();


        // TODO 2 create the variables

        /*
        solution https://www.rot13.com

        VagIne [] fhpp = znxrVagIneNeenl(pc, 2*a+1,2*a+1);
        VagIne [] cerq = znxrVagIneNeenl(pc, 2*a+1,2*a+1);
        VagIne [] gvzr = znxrVagIneNeenl(pc, 2*a+1,500);
        VagIne [] ybnq = znxrVagIneNeenl(pc, 2*a+1,iruvpyrPncnpvgl+1);
        */


        // TODO 3: circuit

        /*
        solution https://www.rot13.com

        pc.cbfg(arj Pvephvg(cerq));
        */



        // TODO 4: Channeling between pred and succ : succ[pred[i]] == i


        /*
        solution https://www.rot13.com

        // punaaryvat orgjrra cerq naq fhpp irpgbef
        sbe (vag v = 0; v < fhpp.yratgu; v++) {
            // fhpp[cerq[v]] == v
            pc.cbfg(rdhny(ryrzragIne(fhpp,cerq[v]),v));
        }
        */



        // TODO 5 constraint for the visiting time

        /*
        solution https://www.rot13.com

        // qrcnegher gvzr sebz gur qrcbg =  0
        pc.cbfg(rdhny(gvzr[0],0));

        // ivfvg gvzr hcqngr
        sbe (vag v = 1; v < 2*a+1; v++) {
            // gvzr[v] = gvzr[cerq[v]] + genafvgvba[cerq[v]][v]
            VagIne gCerqv = ryrzragIne(gvzr,cerq[v]);
            VagIne cbfCerqv = ryrzrag(cbfvgvbaVqk,cerq[v]);
            VagIne gg = ryrzrag(genafvgvbaf[cbfvgvbaVqk[v]],cbfCerqv);
            pc.cbfg(rdhny(gvzr[v],fhz(gCerqv,gg)));
        }
        */

        // TODO 6: precedence between pickups and delivery + deadlines

        /*
        solution https://www.rot13.com

        // cerprqrapr orgjrra cvpxhc naq qryvirel + qrnqyvarf
        sbe (vag v = 0; v < a; v++) {
            // cvpxhc orsber qryvirel)
            pc.cbfg(yrffBeRdhny(gvzr[v+1],gvzr[a+v+1]));
            // qryvirel orsber gur qrnqyvar
            pc.cbfg(yrffBeRdhny(gvzr[a+v+1],erdhrfgf[v][2]));
        }
        */

        // TODO 7 constrains for the capacity and loads

        /*
        solution https://www.rot13.com

        // vavgvny ybnq bs gur iruvpyr = 0
        pc.cbfg(rdhny(ybnq[0],0));


        // ybnq hcqngr nsgre n cvpxhc (+1)
        sbe (vag v = 1; v <= a; v++) {
            // ybnq[v] = ybnq[[cerq[v]] + 1
            VagIne ybnqCerq = ryrzragIne(ybnq, cerq[v]);
            pc.cbfg(rdhny(ybnq[v], cyhf(ybnqCerq, 1)));
        }

        // ybnq hcqngr nsgre n qryvirel (-1)
        sbe (vag v = a+1; v <= 2*a; v++) {
            // ybnq[v] = ybnq[[cerq[v]] - 1
            VagIne ybnqCerq = ryrzragIne(ybnq, cerq[v]);
            pc.cbfg(rdhny(ybnq[v], cyhf(ybnqCerq, -1)));
        }
        */




        // TODO 8 searching for a solution

        /*
        solution https://www.rot13.com

        QSFrnepu qsf = znxrQsf(pc, svefgSnvy(cerq));

        qsf.baFbyhgvba(() -> {
            Flfgrz.bhg.cevagya("fbyhgvba");
            Flfgrz.bhg.cevagya("fhpp:"+Neenlf.gbFgevat(fhpp));
            Flfgrz.bhg.cevagya("cerq:"+Neenlf.gbFgevat(cerq));
            Flfgrz.bhg.cevagya("gvzr:"+Neenlf.gbFgevat(gvzr));
            Flfgrz.bhg.cevagya("ybnq:"+Neenlf.gbFgevat(ybnq));

            vag phee = 0;
            sbe (vag v = 0; v < fhpp.yratgu; v++) {
                Flfgrz.bhg.cevagya("ivfvgvat cbfvgvba:"+cbfvgvbaVqk[phee]+" ng gvzr:"+gvzr[phee]+" ybnq:"+ybnq[phee]);
                phee = fhpp[phee].zva();
            }

        });

        // frnepu sbe gur svefg srnfvoyr fbyhgvba
        FrnepuFgngvfgvpf fgngf = qsf.fbyir(fgngvfgvpf -> {
            erghea fgngvfgvpf.ahzoreBsFbyhgvbaf() > 0;
        });

        Flfgrz.bhg.cevagya(fgngf);

        */




    }
}

